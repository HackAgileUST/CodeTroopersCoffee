﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Data;
using clsBussiness;

namespace webCoffeShop
{
    public partial class frmProductsServer : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            clsBussiness.clsProduct clsProd = new clsProduct();

            DataTable dt;
            dt = clsProd.getProductsGral();

            this.dtlstProducts.DataSource = dt;
            this.dtlstProducts.DataBind();
        }
    }
}