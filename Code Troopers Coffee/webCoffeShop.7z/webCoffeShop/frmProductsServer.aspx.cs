﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Data;
using clsBussiness;

namespace webCoffeShop
{
    public partial class frmProducts : System.Web.UI.Page
    {

    }
}