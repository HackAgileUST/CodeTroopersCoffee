﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Script.Serialization;
using System.Data;
using clsBussiness;

namespace webCoffeShop
{
    public partial class frmProducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            clsBussiness.clsProduct clsProd = new clsProduct();

            DataTable dt;
            dt = clsProd.getProductsGral();

            //this.grvwProducts.DataSource = dt;
            //this.grvwProducts.DataBind();
            //Session.Add("prueba", dt.Rows[0].ItemArray[1]);

            JavaScriptSerializer jsSerializer = new JavaScriptSerializer();
            List<Dictionary<string, object>> parentRow = new List<Dictionary<string, object>>();
            Dictionary<string, object> childRow;
            
            foreach (DataRow dtRow in dt.Rows)
            {
                childRow = new Dictionary<string, object>();
                foreach (DataColumn col in dt.Columns)
                {
                    childRow.Add(col.ColumnName, dtRow[col]);
                }
                parentRow.Add(childRow);  
            }

            Session.Add("data", jsSerializer.Serialize(parentRow));
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            
        }
    }
}