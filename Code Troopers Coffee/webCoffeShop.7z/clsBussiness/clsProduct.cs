﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using clsData;

namespace clsBussiness
{
    public class clsProduct
    {
        private clsData.clsODBC clsDat;

        public DataTable getProductsGral()
        {
            clsDat = new clsODBC();

            DataTable dt = new DataTable();

            dt = clsDat.getDataTable("SELECT Product.idProduct, Product.shortName, Product.imageURL, sizeProduct.idSize, sizeProduct.Description, " + 
                "skuProduct.Price FROM sizeProduct INNER JOIN (Product INNER JOIN skuProduct ON Product.idProduct = skuProduct.idProduct) " +
                "ON sizeProduct.idSize = skuProduct.idSize;");

            return dt;
        }
    }
}
