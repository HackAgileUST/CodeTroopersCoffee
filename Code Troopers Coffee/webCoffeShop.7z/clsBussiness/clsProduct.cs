﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using clsData;

namespace clsBussiness
{
    public class clsProduct
    {
        private clsData.clsODBC clsDat;

        public DataTable getProductsGral()
        {
            clsDat = new clsODBC();

            DataTable dt = new DataTable();

            //dt = clsDat.getDataTable("SELECT Product.idProduct, Product.shortName, Product.Description, Product.imageURL " +
            //    "FROM Product ORDER BY idProduct");

            dt = clsDat.getDataTable("SELECT * FROM Product INNER JOIN qrPivotBest AS T1 ON T1.idProduct = Product.idProduct" + 
                " ORDER BY Product.idProduct");

            return dt;
        }

        public DataTable getProductsPrice()
        {
            clsDat = new clsODBC();

            DataTable dt = new DataTable();

            dt = clsDat.getDataTable("SELECT skuProduct.idProduct, skuProduct.idSize, sizeProduct.Description, skuProduct.Price " +
                "FROM sizeProduct INNER JOIN skuProduct ON sizeProduct.idSize = skuProduct.idSize " +
                "ORDER BY skuProduct.idProduct, skuProduct.idSize;");

            return dt;
        }
    }
}
