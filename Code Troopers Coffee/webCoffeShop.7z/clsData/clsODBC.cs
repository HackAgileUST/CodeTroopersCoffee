﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.Odbc;

namespace clsData
{
    public class clsODBC
    {
        private OdbcConnection odbcCon;
        private OdbcDataAdapter odbcAdap;
        private OdbcCommand odbcComm;

        private string mStringCnx = "DSN=dsCoffeShop";

        public string linkCnx
        {
            get { return mStringCnx; }
            set { mStringCnx = linkCnx; }
        }

        private void declareConnection()
        {
            odbcCon = new OdbcConnection();
        }

        private void declareCommand(string strQuery)
        {
            odbcComm = new OdbcCommand(strQuery,odbcCon);
        }

        private void declareDataAdapter()
        {
            odbcAdap = new OdbcDataAdapter(odbcComm);
        }

        private void setStringConnection()
        {
            odbcCon.ConnectionString = linkCnx;
        }

        private bool Connect()
        {
            declareConnection();
            setStringConnection();
            if (odbcCon.State == ConnectionState.Closed)
            {
                odbcCon.Open();
                return true;
            }
            return false;
        }

        private bool Deconnect()
        {
            if (odbcCon.State == ConnectionState.Open)
            {
                odbcCon.Close();
                return true;
            }
            return false;
        }

        public DataTable getDataTable(string strQuery)
        {
            DataSet ds = new DataSet();
            
            if (Connect())
            {
                declareCommand(strQuery);
                declareDataAdapter();
                odbcAdap.Fill(ds);
                Deconnect();
            }

            return ds.Tables[0];
        }

        public int executeScalar(string query)
        {
            return 0;
        }
    }
}
